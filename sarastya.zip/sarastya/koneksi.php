<?php
$conn = mysqli_connect("localhost", "root", "", "pendaftaran");
if (!$conn) {
    echo "Gagal koneksi";
}
